//
//  Ryteworks_Constants.h
//  ryteworks
//
//  Created by zucmac on 28/01/17.
//  Copyright © 2017 Zucite. All rights reserved.
//

#ifndef Ryteworks_Constants_h
#define Ryteworks_Constants_h

#define kRW_GetConfigurationUrl @"/api/consumer/configuration"
#define kRW_PostTrackingDataUrl @"/api/consumer/tracking/%@"
#define kRW_GetGeofenceRegionUrl @"/api/consumer/geofence"
#define kRW_ReceivedNotificationUrl @"/api/consumer/receivednotification"
#define kRW_ReadNotificationUrl @"/api/consumer/readnotification"
#define kRW_ClearNotificationUrl @"/api/consumer/clearNotification/%@"
#define kRW_ListNotificationUrl @"/api/consumer/listNotification/%@"


#endif /* Ryteworks_Constants_h */
