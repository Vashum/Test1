//
//  ConfigurationDataModel.h
//  ryteworks
//
//  Created by zucmac on 28/01/17.
//  Copyright © 2017 Zucite. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ConfigurationDataModel : NSObject
    
    // Singleton method
+ (id)sharedInstance;
  // Persist all in DB
@property (nonatomic) CGFloat beaconEventLoggingInterval;
@property (nonatomic) CGFloat gpsEventLoggingInterval;
@property (nonatomic) CGFloat geoFencePollingInterval;
@property (nonatomic) CGFloat geoFenceRadius;
@property (nonatomic) NSDate *lastGeofencePollDateTime;
@property (nonatomic) NSDate *lastBeaconSentDateTime;
@property (nonatomic) CLLocation *lastKnownGeofencePosition;
@property (nonatomic) NSString *userId;
@property (nonatomic) NSString *fcmToken;

- (void)setUpConfigurationData: (NSDictionary *)configDict;

@end
