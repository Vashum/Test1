//
//  QRScannerViewController.h
//  ryteworks SDK
//
//  Created by zucmac on 24/02/16.
//  Copyright © 2016 Zucite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QRScannerViewController : UIViewController
@property NSString *userID;
@end
