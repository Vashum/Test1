//
//  PostQueue.h
//  Trakryt
//
//  Created by zucmac on 15/06/15.
//  Copyright (c) 2015 SANDEEP KUMAR. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RWDatabsePath.h"
#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface RyteworksDatabase : NSObject

// Persistent data storage for post data failure
+ (RyteworksDatabase*)sharedInstance;

- (void)createConfigTable;
- (void)dropConfigTable;
- (void)insertIntoConfigTableUserIdAndFcmToken: (NSDictionary *)data;
- (void)insertIntoConfigTableConfigService: (NSDictionary *)data;

- (NSMutableArray*) retrieveAllFromConfigTable;

// UserId and FcmToken
- (void)insertUserId: (NSString *)userId;
- (void)insertFcmToken: (NSString *)fcmToken;
- (NSString *)getUserId;
- (NSString *)getFcmToken;

//

- (void)insertLastGeofencePollDateTime: (NSString *)dateTime;
- (void)insertLastBeaconSentDateTime: (NSString *)dateTime;
- (void)insertLastKnownGeofencePosition: (CLLocation *)coordinate;

- (NSDate *)getLastGeofencePollDateTime;
- (NSDate *)getLastBeaconSentDateTime;
- (CLLocation *)getLastKnownGeofencePosition;

- (CGFloat)getBeaconEventLoggingInterval;
- (CGFloat)getGpsEventLoggingInterval;
- (CGFloat)getGeoFencePollingInterval;
- (CGFloat)getGeoFenceRadius;



@end
