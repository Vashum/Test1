//
//  LocationServiceHelper.h
//  ryteworks SDK
//
//  Created by zucmac on 24/02/16.
//  Copyright © 2016 Zucite. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <UIKit/UIKit.h>



@interface LocationServiceHelper : NSObject
@property(nonatomic, strong) CLLocationManager *locationManager;
@property(nonatomic, strong) CLBeaconRegion  *beaconRegion;
- (void)starLocationService;
- (void)stopLocationService;

@end
