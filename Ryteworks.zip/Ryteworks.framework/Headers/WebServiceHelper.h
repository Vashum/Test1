//
//  WebServiceHelper.h
//  ryteworks
//
//  Created by zucmac on 28/01/17.
//  Copyright © 2017 Zucite. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Ryteworks_Constants.h"

typedef void (^RWWebServiceSuccessBlock)(id responseObject);
typedef void (^RWWebServiceFailureBlock)(NSError *error);

@interface WebServiceHelper : NSObject

+ (id)sharedInstance;

- (void)callWebServiceWithUrlString:(NSString *)urlString
                         parameters:(NSDictionary *)parameters
                            success:(RWWebServiceSuccessBlock) success
                            failure:(RWWebServiceFailureBlock) failure;


@end
